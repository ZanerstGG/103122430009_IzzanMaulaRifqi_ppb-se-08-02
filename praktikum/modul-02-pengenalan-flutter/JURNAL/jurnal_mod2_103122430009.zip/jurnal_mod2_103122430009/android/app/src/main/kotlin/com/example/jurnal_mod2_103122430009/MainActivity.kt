package com.example.jurnal_mod2_103122430009

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
